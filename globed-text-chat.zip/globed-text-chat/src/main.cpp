#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/utils/web.hpp>

#include <algorithm>
#include <chrono>
#include <cctype>
#include <deque>
#include <sstream>
#include <string>
#include <vector>

using namespace geode::prelude;

namespace {
    constexpr int kMaxVisibleLines = 7;
    constexpr int kMaxMessageLength = 100;

    std::string trim(std::string value) {
        auto notSpace = [](unsigned char c) { return !std::isspace(c); };
        value.erase(value.begin(), std::find_if(value.begin(), value.end(), notSpace));
        value.erase(std::find_if(value.rbegin(), value.rend(), notSpace).base(), value.end());
        return value;
    }

    std::string sanitizeLine(std::string value) {
        value = trim(value);
        value.erase(std::remove(value.begin(), value.end(), '\n'), value.end());
        value.erase(std::remove(value.begin(), value.end(), '\r'), value.end());
        value.erase(std::remove(value.begin(), value.end(), '\t'), value.end());
        if (value.size() > kMaxMessageLength) {
            value.resize(kMaxMessageLength);
        }
        return value;
    }

    std::string shorten(std::string value, size_t maxLen) {
        if (value.size() <= maxLen) return value;
        if (maxLen <= 3) return value.substr(0, maxLen);
        return value.substr(0, maxLen - 3) + "...";
    }

    std::string urlEncode(std::string const& value) {
        static const char* hex = "0123456789ABCDEF";
        std::string out;
        out.reserve(value.size() * 3);
        for (unsigned char c : value) {
            if (std::isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
                out.push_back(static_cast<char>(c));
            } else if (c == ' ') {
                out.push_back('+');
            } else {
                out.push_back('%');
                out.push_back(hex[c >> 4]);
                out.push_back(hex[c & 15]);
            }
        }
        return out;
    }

    std::string getSettingString(char const* key, std::string fallback) {
        try {
            return Mod::get()->getSettingValue<std::string>(key);
        } catch (...) {
            return fallback;
        }
    }

    int64_t getSettingInt(char const* key, int64_t fallback) {
        try {
            return Mod::get()->getSettingValue<int64_t>(key);
        } catch (...) {
            return fallback;
        }
    }

    bool getSettingBool(char const* key, bool fallback) {
        try {
            return Mod::get()->getSettingValue<bool>(key);
        } catch (...) {
            return fallback;
        }
    }
}

struct ChatMessage {
    int64_t id = 0;
    std::string player;
    std::string text;
};

class GlobedChatOverlay : public CCLayer {
protected:
    PlayLayer* m_playLayer = nullptr;
    CCLayerColor* m_panel = nullptr;
    CCLayerColor* m_inputBack = nullptr;
    CCTextInputNode* m_input = nullptr;
    CCMenu* m_buttonMenu = nullptr;
    CCMenu* m_sendMenu = nullptr;
    CCLabelBMFont* m_status = nullptr;
    CCLabelBMFont* m_lines[kMaxVisibleLines] = { nullptr };

    std::deque<ChatMessage> m_messages;
    TaskHolder<web::WebResponse> m_pollTask;
    TaskHolder<web::WebResponse> m_sendTask;
    int64_t m_lastMessageId = 0;
    bool m_chatOpen = true;
    bool m_polling = false;
    double m_nextSendAllowedAt = 0.0;

    bool init(PlayLayer* playLayer) {
        if (!CCLayer::init()) return false;
        m_playLayer = playLayer;
        this->setID("globed-text-chat-overlay");

        auto winSize = CCDirector::sharedDirector()->getWinSize();

        // Small toggle button, like Roblox chat sitting top-left.
        m_buttonMenu = CCMenu::create();
        m_buttonMenu->setPosition({ 0.f, 0.f });
        this->addChild(m_buttonMenu, 20);

        auto toggleSprite = ButtonSprite::create("Chat");
        toggleSprite->setScale(.55f);
        auto toggle = CCMenuItemSpriteExtra::create(
            toggleSprite,
            this,
            menu_selector(GlobedChatOverlay::onToggle)
        );
        toggle->setPosition({ 35.f, winSize.height - 22.f });
        m_buttonMenu->addChild(toggle);

        // Roblox-like translucent panel.
        m_panel = CCLayerColor::create(ccc4(18, 18, 24, 150), 300.f, 155.f);
        m_panel->setAnchorPoint({ 0.f, 1.f });
        m_panel->setPosition({ 8.f, winSize.height - 48.f - 155.f });
        this->addChild(m_panel, 5);

        auto title = CCLabelBMFont::create("Text Chat", "chatFont.fnt");
        title->setAnchorPoint({ 0.f, 1.f });
        title->setScale(.55f);
        title->setColor(ccc3(220, 220, 220));
        title->setPosition({ 10.f, 148.f });
        m_panel->addChild(title);

        m_status = CCLabelBMFont::create("connecte au serveur...", "chatFont.fnt");
        m_status->setAnchorPoint({ 0.f, 1.f });
        m_status->setScale(.38f);
        m_status->setColor(ccc3(170, 170, 170));
        m_status->setPosition({ 82.f, 146.f });
        m_panel->addChild(m_status);

        for (int i = 0; i < kMaxVisibleLines; i++) {
            auto label = CCLabelBMFont::create("", "chatFont.fnt");
            label->setAnchorPoint({ 0.f, 1.f });
            label->setScale(.42f);
            label->setColor(ccc3(245, 245, 245));
            label->setPosition({ 10.f, 124.f - static_cast<float>(i) * 14.f });
            m_panel->addChild(label);
            m_lines[i] = label;
        }

        m_inputBack = CCLayerColor::create(ccc4(5, 5, 8, 180), 224.f, 24.f);
        m_inputBack->setAnchorPoint({ 0.f, 0.f });
        m_inputBack->setPosition({ 9.f, 7.f });
        m_panel->addChild(m_inputBack);

        m_input = CCTextInputNode::create(208.f, 24.f, "Tap to chat...", "chatFont.fnt");
        m_input->setPosition({ 121.f, 18.f });
        m_input->setScale(.55f);
        m_input->setMaxLabelLength(kMaxMessageLength);
        m_panel->addChild(m_input, 2);

        m_sendMenu = CCMenu::create();
        m_sendMenu->setPosition({ 0.f, 0.f });
        m_panel->addChild(m_sendMenu, 10);

        auto sendSprite = ButtonSprite::create("Send");
        sendSprite->setScale(.45f);
        auto send = CCMenuItemSpriteExtra::create(
            sendSprite,
            this,
            menu_selector(GlobedChatOverlay::onSend)
        );
        send->setPosition({ 265.f, 18.f });
        m_sendMenu->addChild(send);

        this->schedule(schedule_selector(GlobedChatOverlay::onPollTick), 1.0f);
        this->schedule(schedule_selector(GlobedChatOverlay::onCooldownTick), .1f);
        this->pollNow();
        return true;
    }

    std::string getServerBase() const {
        auto url = getSettingString("server-url", "http://127.0.0.1:8080");
        while (!url.empty() && url.back() == '/') url.pop_back();
        return url;
    }

    std::string getNickname() const {
        auto name = sanitizeLine(getSettingString("nickname", "Player"));
        if (name.empty()) name = "Player";
        if (name.size() > 20) name.resize(20);
        return name;
    }

    std::string getRoom() const {
        // v1: messages are grouped by level id. Everyone on the same level + same relay server sees the same chat.
        // If you later use the official Globed API for room/server IDs, replace this string with that room key.
        int64_t id = 0;
        if (m_playLayer && m_playLayer->m_level) {
            id = m_playLayer->m_level->m_levelID.value();
        }
        return "level-" + std::to_string(id);
    }

    double nowSeconds() const {
        using clock = std::chrono::steady_clock;
        return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
    }

    void addMessage(ChatMessage msg) {
        if (msg.id <= m_lastMessageId && msg.id != 0) return;
        if (msg.id > m_lastMessageId) m_lastMessageId = msg.id;
        msg.player = sanitizeLine(msg.player);
        msg.text = sanitizeLine(msg.text);
        if (msg.player.empty()) msg.player = "Player";
        if (msg.text.empty()) return;

        m_messages.push_back(msg);
        while (m_messages.size() > 50) m_messages.pop_front();
        this->refreshLines();
    }

    void addLocalStatus(std::string const& text) {
        if (m_status) m_status->setString(text.c_str());
    }

    void refreshLines() {
        std::vector<std::string> visible;
        int start = std::max<int>(0, static_cast<int>(m_messages.size()) - kMaxVisibleLines);
        for (int i = start; i < static_cast<int>(m_messages.size()); i++) {
            auto const& msg = m_messages[i];
            visible.push_back(shorten(msg.player + ": " + msg.text, 56));
        }

        for (int i = 0; i < kMaxVisibleLines; i++) {
            if (!m_lines[i]) continue;
            if (i < static_cast<int>(visible.size())) {
                m_lines[i]->setString(visible[i].c_str());
            } else {
                m_lines[i]->setString("");
            }
        }
    }

    void parsePollResponse(std::string const& body) {
        std::stringstream ss(body);
        std::string line;
        int received = 0;

        while (std::getline(ss, line)) {
            if (line.empty()) continue;
            auto first = line.find('\t');
            auto second = first == std::string::npos ? std::string::npos : line.find('\t', first + 1);
            if (first == std::string::npos || second == std::string::npos) continue;

            ChatMessage msg;
            try {
                msg.id = std::stoll(line.substr(0, first));
            } catch (...) {
                continue;
            }
            msg.player = line.substr(first + 1, second - first - 1);
            msg.text = line.substr(second + 1);
            this->addMessage(msg);
            received++;
        }

        addLocalStatus(received > 0 ? "messages recus" : "en ligne");
    }

    void pollNow() {
        if (m_polling) return;
        auto base = getServerBase();
        if (base.empty()) {
            addLocalStatus("URL serveur manquante");
            return;
        }

        m_polling = true;
        auto url = base + "/api/poll?room=" + urlEncode(getRoom()) + "&after=" + std::to_string(m_lastMessageId);
        auto req = web::WebRequest();
        req.userAgent("GlobedTextChat/1.0");
        req.timeout(std::chrono::seconds(8));

        m_pollTask.spawn(
            req.get(url),
            [this](web::WebResponse res) {
                m_polling = false;
                if (!res.ok()) {
                    addLocalStatus("serveur indisponible");
                    return;
                }
                auto body = res.string().unwrapOr("");
                this->parsePollResponse(body);
            }
        );
    }

    void onPollTick(float) {
        if (!m_chatOpen) return;
        this->pollNow();
    }

    void onCooldownTick(float) {
        // Keeps the layer alive and gives a place for future animation / fade-out.
    }

    void onToggle(CCObject*) {
        m_chatOpen = !m_chatOpen;
        if (m_panel) m_panel->setVisible(m_chatOpen);
        if (m_chatOpen) this->pollNow();
    }

    void onSend(CCObject*) {
        auto raw = m_input ? std::string(m_input->getString()) : std::string();
        auto message = sanitizeLine(raw);
        if (message.empty()) return;

        auto now = nowSeconds();
        auto cooldownMs = getSettingInt("cooldown-ms", 2500);
        if (now < m_nextSendAllowedAt) {
            addLocalStatus("attends un peu...");
            return;
        }
        m_nextSendAllowedAt = now + static_cast<double>(cooldownMs) / 1000.0;

        auto base = getServerBase();
        if (base.empty()) {
            addLocalStatus("URL serveur manquante");
            return;
        }

        auto body = std::string("room=") + urlEncode(getRoom()) +
            "&player=" + urlEncode(getNickname()) +
            "&message=" + urlEncode(message);

        auto req = web::WebRequest();
        req.userAgent("GlobedTextChat/1.0");
        req.header("Content-Type", "application/x-www-form-urlencoded");
        req.timeout(std::chrono::seconds(8));
        req.bodyString(body);

        addLocalStatus("envoi...");
        if (m_input) m_input->setString("");

        m_sendTask.spawn(
            req.post(base + "/api/send"),
            [this](web::WebResponse res) {
                if (!res.ok()) {
                    addLocalStatus("message non envoye");
                    return;
                }
                addLocalStatus("envoye");
                this->pollNow();
            }
        );
    }

public:
    static GlobedChatOverlay* create(PlayLayer* playLayer) {
        auto ret = new GlobedChatOverlay();
        if (ret && ret->init(playLayer)) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
};

class $modify(GlobedChatPlayLayer, PlayLayer) {
    struct Fields {
        GlobedChatOverlay* m_overlay = nullptr;
    };

    bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
        if (!PlayLayer::init(level, useReplay, dontCreateObjects)) {
            return false;
        }

        if (!getSettingBool("enabled", true)) {
            return true;
        }

        auto overlay = GlobedChatOverlay::create(this);
        if (overlay) {
            this->addChild(overlay, 9999);
            m_fields->m_overlay = overlay;
            log::info("Globed Text Chat overlay added");
        }
        return true;
    }
};
