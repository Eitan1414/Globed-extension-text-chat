For support, open an issue on your GitHub repository and include:

- platform: Windows64 or Android64
- Geode version
- Globed version
- server URL used
- Geode logs
