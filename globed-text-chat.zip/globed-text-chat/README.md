# Globed Text Chat

Mod Geode prototype pour Geometry Dash qui ajoute un chat texte façon Roblox pendant les niveaux.

Objectif : les joueurs qui ont **Globed + ce mod** peuvent discuter. Windows64 et Android64 peuvent voir et répondre aux mêmes messages si les deux clients utilisent **la même URL de serveur**.

## Ce que contient ce projet

- `src/main.cpp` : overlay de chat dans `PlayLayer`.
- `mod.json` : configuration Geode + dépendance Globed.
- `.github/workflows/build.yml` : workflow GitHub Actions Windows64 + Android64.
- `server/server.js` : petit serveur relay Node.js sans dépendance.

## Fonctionnement

Le mod n'envoie pas les messages directement dans les serveurs officiels de Globed. Il utilise un serveur externe :

```txt
Windows64 Geometry Dash  ─┐
                          ├─> serveur chat ─> messages
Android64 Geometry Dash  ─┘
```

Donc pour que le crossplay marche :

- le joueur Windows et le joueur Android doivent avoir Globed ;
- les deux doivent avoir ce mod ;
- les deux doivent mettre la même valeur dans le réglage `Chat server URL` ;
- les deux doivent être dans le même niveau, car la v1 groupe le chat par `level-id`.

## Lancer le serveur

Sur un PC :

```bash
cd server
node server.js
```

Ensuite, dans les réglages du mod :

- sur le PC : `http://127.0.0.1:8080` marche si le serveur tourne sur le même PC ;
- sur Android : il faut mettre l'IP locale du PC, par exemple `http://192.168.1.25:8080`.

Pour jouer à distance avec des gens qui ne sont pas sur le même Wi-Fi, héberge `server/server.js` sur un hébergeur Node.js et mets l'URL publique dans les réglages du mod.

## Compiler avec GitHub Actions

1. Crée un dépôt GitHub.
2. Envoie tous les fichiers de ce dossier dans le dépôt.
3. Va dans l'onglet **Actions**.
4. Lance **Build Geode Mod**.
5. Télécharge l'artifact `Globed-Text-Chat-Windows64-Android64`.
6. Tu devrais obtenir un `.geode` combiné Windows64 + Android64.

## Installer

- Installe Geode.
- Installe Globed depuis l'index Geode.
- Mets le `.geode` généré dans le dossier des mods Geode.
- Configure `Chat server URL` dans les réglages du mod.

## Important

C'est une base propre de prototype. Si Globed publie ou modifie une API officielle pour récupérer le serveur/la room exacte, remplace la fonction `getRoom()` dans `src/main.cpp`. Pour l'instant, la room utilisée est basée sur l'ID du niveau : `level-<id>`.

## Anti-spam inclus

- 100 caractères max par message.
- 20 caractères max pour le pseudo.
- cooldown client configurable.
- cooldown serveur fixe de 2,5 secondes.
- mémoire limitée à 200 messages par room.
