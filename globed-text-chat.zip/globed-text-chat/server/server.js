// Globed Text Chat relay server
// Windows64 and Android64 clients can chat together if they use the same server URL.
// Run: node server.js

const http = require('http');
const { URL } = require('url');

const PORT = Number(process.env.PORT || 8080);
const MAX_MESSAGE_LENGTH = 100;
const MAX_PLAYER_LENGTH = 20;
const MAX_MESSAGES_PER_ROOM = 200;
const COOLDOWN_MS = 2500;

let nextId = 1;
const rooms = new Map();
const lastSendAt = new Map();

function sanitize(value, maxLength) {
  value = String(value || '')
    .replace(/[\r\n\t]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (value.length > maxLength) value = value.slice(0, maxLength);
  return value;
}

function getRoomMessages(room) {
  if (!rooms.has(room)) rooms.set(room, []);
  return rooms.get(room);
}

function send(res, status, body, contentType = 'text/plain; charset=utf-8') {
  res.writeHead(status, {
    'Content-Type': contentType,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 4096) {
        reject(new Error('body_too_large'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

function clientKey(req, room, player) {
  const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
  return `${ip}|${room}|${player}`;
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') {
      send(res, 204, '');
      return;
    }

    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (req.method === 'GET' && url.pathname === '/') {
      send(res, 200, 'Globed Text Chat relay is running. Endpoints: GET /api/poll, POST /api/send\n');
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/health') {
      send(res, 200, 'ok\n');
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/poll') {
      const room = sanitize(url.searchParams.get('room'), 80) || 'global';
      const after = Number(url.searchParams.get('after') || 0);
      const messages = getRoomMessages(room)
        .filter(msg => msg.id > after)
        .slice(-50);

      const body = messages
        .map(msg => `${msg.id}\t${msg.player}\t${msg.message}`)
        .join('\n');
      send(res, 200, body ? body + '\n' : '');
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/send') {
      const body = await readBody(req);
      const params = new URLSearchParams(body);

      const room = sanitize(params.get('room'), 80) || 'global';
      const player = sanitize(params.get('player'), MAX_PLAYER_LENGTH) || 'Player';
      const message = sanitize(params.get('message'), MAX_MESSAGE_LENGTH);

      if (!message) {
        send(res, 400, 'empty_message\n');
        return;
      }

      const key = clientKey(req, room, player);
      const now = Date.now();
      const last = lastSendAt.get(key) || 0;
      if (now - last < COOLDOWN_MS) {
        send(res, 429, 'cooldown\n');
        return;
      }
      lastSendAt.set(key, now);

      const messages = getRoomMessages(room);
      const entry = {
        id: nextId++,
        ts: now,
        room,
        player,
        message
      };
      messages.push(entry);
      while (messages.length > MAX_MESSAGES_PER_ROOM) messages.shift();

      console.log(`[${room}] ${player}: ${message}`);
      send(res, 200, `${entry.id}\n`);
      return;
    }

    send(res, 404, 'not_found\n');
  } catch (err) {
    console.error(err);
    send(res, 500, 'server_error\n');
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Globed Text Chat relay listening on http://0.0.0.0:${PORT}`);
});
