# Globed Text Chat relay server

Ce serveur est le point commun entre les joueurs Windows64 et Android64.

## Lancer en local

```bash
node server.js
```

Le serveur écoute sur :

```txt
http://0.0.0.0:8080
```

## Pour tester Windows + Android sur le même Wi-Fi

1. Lance le serveur sur le PC.
2. Trouve l'adresse IP locale du PC, par exemple `192.168.1.25`.
3. Dans les paramètres du mod sur Windows et Android, mets :

```txt
http://192.168.1.25:8080
```

Important : `127.0.0.1` veut dire "cet appareil". Sur Android, `127.0.0.1` pointe vers le téléphone, pas vers ton PC.

## Pour jouer avec des personnes hors de ton Wi-Fi

Héberge ce serveur sur un VPS / Render / Railway / Fly.io / autre hébergeur Node.js, puis utilise l'URL publique HTTPS dans les paramètres du mod.

## Endpoints

- `GET /api/health`
- `GET /api/poll?room=level-123&after=0`
- `POST /api/send` avec body `application/x-www-form-urlencoded`

Champs POST :

- `room`
- `player`
- `message`
