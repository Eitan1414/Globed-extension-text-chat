# Globed Text Chat

A Roblox-like text chat overlay for Geometry Dash / Geode players who also use Globed.

This mod does not try to inject messages into official Globed servers. It uses an external relay server so Windows64 and Android64 players can talk together when they use the same server URL.
