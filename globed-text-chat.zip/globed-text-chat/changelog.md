# v1.0.0

- First prototype.
- Roblox-like translucent chat panel.
- Windows64 + Android64 GitHub Actions workflow.
- Simple Node.js relay server.
